
package categoryui;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.Button;

public class CategoryUIController implements Initializable {
    
    @FXML private Button leftTicketButton;
    @FXML private Button leftCategoryButton;
    @FXML private Button leftUsersButton;
    @FXML private Button leftRoadButton;
    @FXML private Button removeButton;
    @FXML private Button editButton;
    @FXML private Button createButton;
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        // TODO
    }    
    @FXML protected void leftTicketPressed(ActionEvent event) throws IOException
    {
        
    }
    @FXML protected void leftCategoryPressed(ActionEvent event) throws IOException
    {
        
    }
    @FXML protected void leftUserPressed(ActionEvent event) throws IOException
    {
        
    }
    @FXML protected void leftRoadPressed(ActionEvent event) throws IOException
    {
        
    }
     @FXML protected void removeButtonPressed(ActionEvent event) throws IOException
    {
        
    }
      @FXML protected void editButtonPressed(ActionEvent event) throws IOException
    {
        
    }
     @FXML protected void createButtonPressed(ActionEvent event) throws IOException
    {
        
    }
    
}
