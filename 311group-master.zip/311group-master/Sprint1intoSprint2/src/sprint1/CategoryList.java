
package sprint1;


public class CategoryList {
    
}
